Lights Of Heaven Created By ChaosMoth
http://www.wincustomize.com/users/3163354/ChaosMoth

This cursor set was originally created by ChaosMoth for use with CursorXP.  It was later converted to work with Windows XP's cursor sytem by...JacksMafia over at deviantart.com (http://jacksmafia.deviantart.com/)

======================
How to Install
==========================

Right Click the setup.ini file and choose "Install"
This will copy the cursors and move it into "c:drive > windows > cursors > lights of heaven"
Next go to your control panel and choose "Mouse"
Click on the "Pointers" Options
Under Schemes, choose "Lights Of Heaven"
Click Apply

Instructions brought to you by www.cursors-4u.com and downloaded at www.cursors-4u.com.  Also this cursor set is Cursor Of Month for Febuary 2011.